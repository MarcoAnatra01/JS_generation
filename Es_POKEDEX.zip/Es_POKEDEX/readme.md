# Pokedex

NB: al caricamento della pagina deve esserci un form nel quale nel quale si chiede all'utente il suo nome

Utilizzando l'API pokemon, stampa una lista casuale dei pokemon.

URL endpoint API pokemon:
https://pokeapi.co/api/v2/pokemon/?limit=20&offset=0

Accanto ad ogni pokemon un btn "Inserisci nel Pokedex" con un max di 3 pokemon iniziali.

Raggiunti i 3 pokemon, non se ne possono inserire altri.

In alto ci sarà una navbar con la voce "Pokedex", cliccando su questa voce verremo reindirizzati alla pagina nella quale verranno mostrati i 3 pokemon scelti.


singolo elemento pokemon
    proprietà url (oggetto con tutte le proprietà del singolo pokemon)
        proprietà con img gif
        altre proprietà


Per ogni pokemon scelto dovrà esserci la possibilità di modificare le informazioni. Se ci sono vengono mostrate nella card stessa.

Nella card dovrà esserci la voce "Localizza", al click su questa voce compare una mappa con il segnale della posizione del pokemon.

Alla comparsa della mappa comparirà un altra voce "Controlla meteo nella località". Al click compare una finestra nella quale verrà mostrato il meteo attuale (temperatura, meteo icona, umidità).   

Al click sul pulsante modifica posso aggiungere altre info attraverso un form dedicato inserendo:
nickname: 
geolocalizzazione: inserire un indirizzo 




CSS: 
BOOTSTRAP 

page home:
usare una list-group di bs5 per mostrare i pokemon 

all'inserimento del pokemon, far comparire un avviso alert bs5  (dismissable) con posizione absolute in basso a destra dello schermo.

Pokedex: Usare le card di bs5

per ogni card pokemon: 
-nome pokemon
-descrizione
-immagine

