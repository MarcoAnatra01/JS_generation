#### Storage

Crea una pagina con un form con le proprietà:
nome, cognome, mail, username, avatar(link ad una img esterna presa da internet)

al click sul btn registra :
- controllare i campi
- se tutto corretto:
- i dati sono salvati nella local storage
- spostarsi sulla pagina di "benvenuto"


l'utente dovrà essere un oggetto da salvare nella local storage

all'arrivo sulla pagina di "benvenuto" deve comparire un saluto all'utente 


ogni pagina html ha il suo script

lo script per la pagina di benvenuto 




------------------------------------
CSS pagina di benvenuto:

pagina di profilo sul sito

avatar con nome affiancato e le altre info

sotto ci deve essere il pulsante "modifica" sul quale al click deve comparire un div con all'interno un form i cui campi saranno già compilati con i valori dell'utente


i form devono essere fatti con le classi di bootstrap 
i campi dei form devono essere ingrigliati bene

