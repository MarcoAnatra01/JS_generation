
let nome = document.querySelector("#nome");
let cognome = document.querySelector("#cognome");
let username = document.querySelector("#username");
let email = document.querySelector("#email");
let avatar = document.querySelector("#avatar");

let formReg = document.querySelector("#formReg");

let btnRegistra = document.querySelector("#btnRegistra");


let errorBox = document.querySelector("#errorBox");

let alertDiv = `<div class="alert alert-danger alert-dismissible fade show" role="alert">`;

let alertBtn = `<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>`;

let feedback = document.querySelector("#feedback");



function controlla(){

    if (nome.value != "" && cognome.value != "" && username.value != "" && email.value != "" && avatar.value != "") {
        
        // tutti i campi del form sono compilati 

        let user = {
            nome: nome.value,
            cognome: cognome.value,
            username: username.value,
            email: email.value,
            avatar: avatar.value
        }

        let userJSON = JSON.stringify(user);
        
        // salvo userJSON nella local storage con key "user"
        localStorage.setItem("user", userJSON);

        return true;
    
    }else{

        if (nome.value == "") {
            nome.setAttribute("style", "border: 2px solid #990033;");
            errorBox.innerHTML += alertDiv + alertBtn + `<strong> Attento! </strong> Hai dimenticato il nome. </div>`;
            
        }

        if (cognome.value == "") {
            cognome.setAttribute("style", "border: 2px solid #990033;");
            
            
        }

        if (username.value == "") {
            username.setAttribute("style", "border: 2px solid #990033;");
            
        }

        if (email.value == "") {
            email.setAttribute("style", "border: 2px solid #990033;");
            
        }

        if (avatar.value == "") {
            avatar.setAttribute("style", "border: 2px solid #990033;");
            
        }

        return false;

    }
}



avatar.addEventListener("blur", function(){
    if (nome.value == "" || cognome.value == "" || username.value == "" || email.value == "" || avatar.value == "") {

        feedback.setAttribute("class", "txtRed");
        feedback.innerHTML = "<strong> Attenzione: Occorre compilare tutti i campi per procedere !";
    }else{

        feedback.innerHTML = "";
    }
});



formReg.addEventListener("submit", function(event){

    // per prima cosa controllo i campi
    controlla();

    if (!controlla()) {

        // controlla() ritorna false
        // form non compilato correttamente
        // allora il submit non avviene

        event.preventDefault();

    }

    // controlla() ritorna true 
    // tutti i campi sono compilati
    // si passa alla pagina di benvenuto
    
    errorBox.innerHTML = "";
    nome.value = "";
    cognome.value = "";
    username.value = "";
    email.value = "";
    avatar.value = "";
});


// feedback.setAttribute("class", "txtGreen");
// feedback.innerHTML = "<strong> Form compilato correttamente, clicca sul pulsante di seguito per concludere. </strong>";